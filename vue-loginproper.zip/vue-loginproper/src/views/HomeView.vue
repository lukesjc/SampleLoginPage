<!-- src/views/HomeView.vue -->
<template>
    <div>
      <h1>Welcome to Home</h1>
    </div>
  </template>
  
  <script setup>
  // Add any necessary script logic here
  </script>
  